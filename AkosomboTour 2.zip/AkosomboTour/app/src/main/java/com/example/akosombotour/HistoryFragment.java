package com.example.akosombotour;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HistoryFragment extends Fragment {
    ArrayAdapter<String> arrayAdapter;
    ListView listView;




    //String[] history_string = getResources().getStringArray(R.array.history_list);
            //{"History of Akosombo Town","Location and Size","Chiefs", "Climate", "Population Composition"};

    public HistoryFragment(){
        //constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.history,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        listView = view.findViewById(R.id.listView);

        //arrayAdapter = new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,history);
        //String history_string = getActivity().getResources().getString(R.string.history_string);
        String history_string = getResources().getString(R.string.history_string);



        //setting ArrayAdapter on listView
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 0) {

                    Intent intent = new Intent(view.getContext(), AkosomboHistory.class);
                    view.getContext().startActivity(intent);
                }

                if (i == 1) {
                    Intent intent = new Intent(view.getContext(), AkosomboLocation.class);
                    view.getContext().startActivity(intent);
                }


                if (i == 2) {
                    Intent intent = new Intent(view.getContext(), AkosomboChiefs.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 3) {
                    Intent intent = new Intent(view.getContext(), AkosomboClimate.class);
                    view.getContext().startActivity(intent);
                }
                //Toast.makeText(getActivity(), "Please Select from the list below", Toast.LENGTH_SHORT).show();
                if (i == 4) {
                    Intent intent = new Intent(view.getContext(), AkosomboPopulation.class);
                    view.getContext().startActivity(intent);
                }
                //Toast.makeText(getActivity(), "Please Select from the list below", Toast.LENGTH_SHORT).show();
            }
        });
        }


    }




